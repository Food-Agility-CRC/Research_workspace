#!/bin/bash
AWS_ACCOUNT_ID=953614670341
AWS_DEFAULT_REGION=ap-southeast-2
REPO_NAME=elasticsearch
ES_VERSION=6.5.4
echo $(aws ecr get-login-password --region $AWS_DEFAULT_REGION)| docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com
docker build --build-arg ES_VERSION=$ES_VERSION -t $REPO_NAME:$ES_VERSION .
docker tag $REPO_NAME:$ES_VERSION $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$REPO_NAME:$ES_VERSION
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$REPO_NAME:$ES_VERSION