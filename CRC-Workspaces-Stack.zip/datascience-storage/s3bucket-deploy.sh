#!/bin/bash
STACK_NAME=dscistorage
if ! aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1; then
    aws cloudformation create-stack --stack-name $STACK_NAME --template-body file://`pwd`/s3bucket-deploy.json --parameters file://s3bucket-params.json --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_NAMED_IAM
else
    aws cloudformation update-stack --stack-name $STACK_NAME --template-body file://`pwd`/s3bucket-deploy.json --parameters file://s3bucket-params.json --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_NAMED_IAM
fi