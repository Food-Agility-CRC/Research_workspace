SSHKEYPAIR='dsci-ec2-vm'
aws ec2 create-key-pair \
  --key-name $SSHKEYPAIR \
  --output text \
  --query 'KeyMaterial' > $SSHKEYPAIR.pem
chmod 400 $SSHKEYPAIR.pem