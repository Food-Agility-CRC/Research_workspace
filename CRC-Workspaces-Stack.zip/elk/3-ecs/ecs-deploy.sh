#!/bin/bash
STACK_NAME=ecs
if ! aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1; then
    aws cloudformation create-stack --stack-name $STACK_NAME --template-body file://`pwd`/ecs.json --parameters file://ecs-params.json --capabilities CAPABILITY_IAM
else
    aws cloudformation update-stack --stack-name $STACK_NAME --template-body file://`pwd`/ecs.json --parameters file://ecs-params.json --capabilities CAPABILITY_IAM
fi