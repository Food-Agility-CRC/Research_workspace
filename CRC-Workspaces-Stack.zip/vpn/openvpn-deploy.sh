#!/bin/bash
STACK_NAME=openvpn
if ! aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1; then
    aws cloudformation create-stack --stack-name $STACK_NAME --template-body file://`pwd`/openvpn-deploy.json --parameters file://openvpn-params.json --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_NAMED_IAM
else
    aws cloudformation update-stack --stack-name $STACK_NAME --template-body file://`pwd`/openvpn-deploy.json --parameters file://openvpn-params.json --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_NAMED_IAM
fi