#!/bin/bash
#--parameters file://awsworkspace-params.json, 
STACK_NAME=AWSWorkspace
USERNAME=$1
if ! aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1; then
    aws cloudformation create-stack --stack-name $STACK_NAME-$(echo $USERNAME|sed -e 's/\.//g') --template-body file://`pwd`/awsworkspace-deploy.json --parameters ParameterKey=User,ParameterValue=$1 ParameterKey=Directory,ParameterValue=d-97671ee3cf ParameterKey=Bundle,ParameterValue=wsb-8vbljg4r6 --capabilities CAPABILITY_NAMED_IAM
else
    aws cloudformation update-stack --stack-name $STACK_NAME-$(echo $USERNAME|sed -e 's/\.//g') --template-body file://`pwd`/awsworkspace-deploy.json --parameters ParameterKey=User,ParameterValue=$1 ParameterKey=Directory,ParameterValue=d-97671ee3cf ParameterKey=Bundle,ParameterValue=wsb-8vbljg4r6 --capabilities CAPABILITY_NAMED_IAM
fi