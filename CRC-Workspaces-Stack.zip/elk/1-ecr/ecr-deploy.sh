STACK_NAME=ecr
if ! aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1; then
    aws cloudformation create-stack --stack-name $STACK_NAME --template-body file://`pwd`/ecr.yaml --parameters file://ecr-parameters.json
else
    aws cloudformation update-stack --stack-name $STACK_NAME --template-body file://`pwd`/ecr.yaml --parameters file://ecr-parameters.json
fi